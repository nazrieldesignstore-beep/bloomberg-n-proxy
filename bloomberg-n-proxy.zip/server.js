// server.js
const express = require("express");
const fetch = require("node-fetch");
const cors = require("cors");
const rateLimit = require("express-rate-limit");

const NEWSAPI_KEY = process.env.NEWSAPI_KEY;
if (!NEWSAPI_KEY) {
  console.warn("WARNING: NEWSAPI_KEY not set. Server will fail to fetch real data.");
}

const PORT = process.env.PORT || 3000;
const CACHE_TTL_MS = parseInt(process.env.CACHE_TTL_MS || "45000");

const app = express();
app.use(cors());
app.use(express.json());

const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
});
app.use(limiter);

const cache = {};

function cacheKey(q, page, pageSize, language) {
  return `q=${q||""}|p=${page||1}|ps=${pageSize||20}|lang=${language||"id"}`;
}

async function fetchFromNewsAPI(q, page = 1, pageSize = 20, language = "id") {
  const url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(q || "ekonomi")}&language=${language}&sortBy=publishedAt&page=${page}&pageSize=${pageSize}&apiKey=${NEWSAPI_KEY}`;
  const res = await fetch(url);
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`NewsAPI error ${res.status}: ${txt}`);
  }
  return res.json();
}

app.get("/news", async (req, res) => {
  try {
    const q = req.query.q || "ekonomi";
    const page = parseInt(req.query.page || "1", 10);
    const pageSize = parseInt(req.query.pageSize || "20", 10);
    const lang = req.query.lang || "id";

    const key = cacheKey(q, page, pageSize, lang);
    const now = Date.now();

    if (cache[key] && now - cache[key].ts < CACHE_TTL_MS) {
      return res.json({ source: "cache", cachedAt: cache[key].ts, ...cache[key].data });
    }

    const data = await fetchFromNewsAPI(q, page, pageSize, lang);
    cache[key] = { ts: now, data };
    return res.json({ source: "newsapi", fetchedAt: now, ...data });
  } catch (err) {
    console.error("Error /news:", err);
    res.status(500).json({ error: err.message });
  }
});

app.get("/health", (req, res) => res.json({ ok: true, ts: Date.now() }));

app.listen(PORT, () => {
  console.log(`BloombergN proxy running on port ${PORT}`);
});
